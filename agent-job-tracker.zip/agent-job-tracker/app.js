// Agent Job Tracker - front-end demo.
// Replace the local data functions later with calls to your Google Apps Script API.

const jobs = [
  { id: 'JOB-1024', agent: 'John Dela Cruz', task: 'Identifying Poles and Lines', session: 'S3', slices: 24, priority: 'High', status: 'In Progress', started: '8:15 AM' },
  { id: 'JOB-1025', agent: 'Sarah Reyes', task: 'Encroachment', session: 'S2', slices: 18, priority: 'Normal', status: 'Completed', started: '8:30 AM' },
  { id: 'JOB-1026', agent: 'Mark Santos', task: 'Identifying Poles and Lines', session: 'S4', slices: 31, priority: 'High', status: 'In Progress', started: '9:00 AM' },
  { id: 'JOB-1027', agent: 'Anna Garcia', task: 'Encroachment', session: 'S1', slices: 22, priority: 'Normal', status: 'In Progress', started: '9:12 AM' },
  { id: 'JOB-1028', agent: 'John Dela Cruz', task: 'Identifying Poles and Lines', session: 'S3', slices: 28, priority: 'Normal', status: 'Completed', started: '10:05 AM' },
  { id: 'JOB-1029', agent: 'Leo Cruz', task: 'Encroachment', session: 'S2', slices: 16, priority: 'High', status: 'Not Started', started: '—' }
];

const agents = [
  { name: 'John Dela Cruz', status: 'Working', job: 'JOB-1024', jobs: 4, slices: 82 },
  { name: 'Sarah Reyes', status: 'Working', job: 'JOB-1025', jobs: 5, slices: 104 },
  { name: 'Mark Santos', status: 'Working', job: 'JOB-1026', jobs: 3, slices: 76 },
  { name: 'Anna Garcia', status: 'Working', job: 'JOB-1027', jobs: 4, slices: 91 },
  { name: 'Leo Cruz', status: 'Available', job: '—', jobs: 2, slices: 34 },
  { name: 'Mia Flores', status: 'Available', job: '—', jobs: 5, slices: 97 }
];

const jobsTableBody = document.getElementById('jobsTableBody');
const searchInput = document.getElementById('searchInput');
const statusFilter = document.getElementById('statusFilter');
const priorityFilter = document.getElementById('priorityFilter');
const toast = document.getElementById('toast');
const jobDialog = document.getElementById('jobDialog');

function initials(name) {
  return name.split(' ').map(part => part[0]).slice(0, 2).join('').toUpperCase();
}

function statusMarkup(status) {
  const map = { 'In Progress': 'status-progress', 'Completed': 'status-complete', 'Not Started': 'status-notstarted' };
  return `<span class="status ${map[status] || 'status-notstarted'}"><span class="status-dot"></span>${status}</span>`;
}

function priorityMarkup(priority) {
  return `<span class="priority ${priority === 'High' ? 'priority-high' : 'priority-normal'}">${priority}</span>`;
}

function renderJobs() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = jobs.filter(job => {
    const matchesQuery = !query || [job.id, job.agent, job.task, job.session].some(value => value.toLowerCase().includes(query));
    const matchesStatus = statusFilter.value === 'All' || job.status === statusFilter.value;
    const matchesPriority = priorityFilter.value === 'All' || job.priority === priorityFilter.value;
    return matchesQuery && matchesStatus && matchesPriority;
  });

  jobsTableBody.innerHTML = filtered.map(job => `
    <tr>
      <td><div class="agent-cell"><span class="avatar">${initials(job.agent)}</span>${job.agent}</div></td>
      <td><strong>${job.id}</strong></td>
      <td class="task-cell">${job.task}</td>
      <td>${job.session}</td>
      <td><strong>${job.slices}</strong></td>
      <td>${job.started}</td>
      <td>${priorityMarkup(job.priority)}</td>
      <td>${statusMarkup(job.status)}</td>
      <td><button class="row-action" data-job="${job.id}" type="button">View</button></td>
    </tr>`).join('');

  document.getElementById('tableCount').textContent = `${filtered.length} ${filtered.length === 1 ? 'job' : 'jobs'}`;

  document.querySelectorAll('.row-action').forEach(button => {
    button.addEventListener('click', () => showToast(`${button.dataset.job} selected — backend connection comes next.`));
  });
}

function renderStats() {
  const active = new Set(jobs.filter(j => j.status === 'In Progress').map(j => j.agent)).size;
  const inProgress = jobs.filter(j => j.status === 'In Progress').length;
  const completed = jobs.filter(j => j.status === 'Completed').length;
  const slices = jobs.reduce((sum, j) => sum + Number(j.slices || 0), 0);
  document.getElementById('activeAgents').textContent = active;
  document.getElementById('inProgressJobs').textContent = inProgress;
  document.getElementById('completedJobs').textContent = completed;
  document.getElementById('totalSlices').textContent = slices.toLocaleString();
}

function renderAgents() {
  document.getElementById('agentsGrid').innerHTML = agents.map(agent => `
    <article class="agent-card">
      <div class="agent-top">
        <div class="agent-avatar">${initials(agent.name)}</div>
        <div><div class="agent-name">${agent.name}</div><div class="agent-state">${agent.status}</div></div>
      </div>
      <div class="agent-meta">
        <div class="agent-metric"><span>Current job</span><strong>${agent.job}</strong></div>
        <div class="agent-metric"><span>Jobs today</span><strong>${agent.jobs}</strong></div>
        <div class="agent-metric"><span>Slices today</span><strong>${agent.slices}</strong></div>
        <div class="agent-metric"><span>Availability</span><strong>${agent.status === 'Working' ? 'Active' : 'Ready'}</strong></div>
      </div>
    </article>`).join('');
}

function renderReportPreview() {
  const poleJobs = jobs.filter(j => j.task === 'Identifying Poles and Lines').length;
  const encroachmentJobs = jobs.filter(j => j.task === 'Encroachment').length;
  const total = jobs.length;
  const polePct = Math.round((poleJobs / total) * 100);
  document.getElementById('taskDonut').style.background = `conic-gradient(var(--forest) 0 ${polePct}%, var(--sage) ${polePct}% 100%)`;
  document.getElementById('taskLegend').innerHTML = `
    <div class="legend-row"><span class="legend-dot" style="background:var(--forest)"></span>Poles &amp; Lines — ${poleJobs}</div>
    <div class="legend-row"><span class="legend-dot" style="background:var(--sage)"></span>Encroachment — ${encroachmentJobs}</div>`;

  const values = [18, 23, 20, 29, 34, 31, 38];
  const max = Math.max(...values);
  document.getElementById('trendChart').innerHTML = values.map(value => `<span class="trend-bar" style="height:${Math.round((value / max) * 88)}%"></span>`).join('');
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 2600);
}

function openJobDialog() {
  const agentSelect = document.getElementById('formAgent');
  agentSelect.innerHTML = agents.map(agent => `<option>${agent.name}</option>`).join('');
  jobDialog.showModal();
}

function createJob(event) {
  event.preventDefault();
  const job = {
    id: document.getElementById('formJob').value.trim(),
    agent: document.getElementById('formAgent').value,
    task: document.getElementById('formTask').value,
    session: document.getElementById('formSession').value,
    slices: Number(document.getElementById('formSlices').value),
    priority: document.getElementById('formPriority').value,
    status: 'Not Started',
    started: '—'
  };
  if (!job.id) return;
  jobs.unshift(job);
  renderAll();
  jobDialog.close();
  event.target.reset();
  showToast(`${job.id} created successfully.`);
}

function renderAll() {
  renderStats();
  renderJobs();
  renderAgents();
  renderReportPreview();
}

document.getElementById('currentDate').textContent = new Intl.DateTimeFormat('en-PH', { dateStyle: 'medium' }).format(new Date());

document.getElementById('newJobButton').addEventListener('click', openJobDialog);
document.getElementById('closeDialog').addEventListener('click', () => jobDialog.close());
document.getElementById('cancelDialog').addEventListener('click', () => jobDialog.close());
document.getElementById('jobForm').addEventListener('submit', createJob);
searchInput.addEventListener('input', renderJobs);
statusFilter.addEventListener('change', renderJobs);
priorityFilter.addEventListener('change', renderJobs);
document.getElementById('clearFilters').addEventListener('click', () => {
  searchInput.value = '';
  statusFilter.value = 'All';
  priorityFilter.value = 'All';
  renderJobs();
});
document.getElementById('reportButton').addEventListener('click', () => showToast('Full reporting module will be connected to Google Sheets next.'));
document.getElementById('themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark');
  localStorage.setItem('agentTrackerTheme', document.body.classList.contains('dark') ? 'dark' : 'light');
});
if (localStorage.getItem('agentTrackerTheme') === 'dark') document.body.classList.add('dark');

renderAll();
